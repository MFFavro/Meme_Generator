usage: meme.py [-h] [--body BODY][--author AUTHOR][--path PATH]

Make a meme!

optional arguments:
    -h, --help      show this help message and exit
    --body BODY     Text to display
    --author AUTHOR Author of text
    --path PATH     Image file path
